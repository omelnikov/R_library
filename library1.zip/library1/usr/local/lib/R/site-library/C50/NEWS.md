# C50 0.1.6

* Maintenance release to fix CRAN issues related to compiler warnings. 


# C50 0.1.5

* Maintenance release to fix CRAN issues related to compiler warnings. 

# C50 0.1.4

* Maintenance release to fix CRAN issues by adding `rmarkdown` to Suggests.

* Fixed CRAN issues related to undefined behavior in the C code when requesting rules with `C5.0(rules = TRUE)`.


# C50 0.1.3

* Fixed CRAN issues for GCC 10 `-fno-common` flag.

* Added a `NEWS.md` file to track changes to the package.

* Removed `churn` data in favor of the version in the `modeldata` package. 
