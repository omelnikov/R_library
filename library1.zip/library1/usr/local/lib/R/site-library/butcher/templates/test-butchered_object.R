context("{{model_class}}")

test_that("{{model_class}} + axe_call() works", {
})

test_that("{{model_class}} + axe_ctrl() works", {
})

test_that("{{model_class}} + axe_data() works", {
})

test_that("{{model_class}} + axe_env() works", {
})

test_that("{{model_class}} + axe_fitted() works", {
})

test_that("{{model_class}} + butcher() works", {
})

test_that("{{model_class}} + predict() works", {
})
